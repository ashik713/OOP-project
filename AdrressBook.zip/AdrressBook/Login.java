 package AddressBook;

public class Login {

	private String userName, password;

	Login(String username,String password){
    	this.userName = username;
    	this.password = password;
    
    }

	public boolean idCheckTourist(){
	   if(userName.equals("1") && password.equals("1")) {
		   return true;
	   }
	   
	   return false;
   }
	public boolean idCheckOwner(){
		   if(userName.equals("1") && password.equals("1")) {
			   return true;
		   }
		   
		   return false;
	   }
}
