

//owner login portion

import javax.swing.JFrame;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class LoginOwner extends Login {
   private static String identity ;
	LoginOwner(String username, String password, String identity) {
		super(username, password);
		this.identity = identity;
		// TODO Auto-generated constructor stub
	}

	static Container c;
	static JButton loginButton;
	static JTextArea ta;
	static JTextField userNameField, field1;
	static Font f, buttonFont;
	static Cursor cursor;
	ImageIcon img1, img2;
	JScrollPane scroll;
	JRadioButton male, female;
	ButtonGroup grp;
	static JLabel userName, password;
	static JComboBox cb;
	static JPasswordField pf;

	public static void main(String[] args) {
		// initComponents();
	}
	@Override
	public boolean idCheckOwner(){
		   if(super.idCheckOwner()==true && identity.equals("o")) {
			   return true;
		   }
		   
		   return false;
	   }


	public static void ownerLoginComponents() {
		JFrame ownerLogin = new JFrame();
		ownerLogin.setVisible(true);
		ownerLogin.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		ownerLogin.setBounds(100, 10, 700, 600); // (x,upor,dan)
		ownerLogin.setTitle("Owner Login Page");
		c = ownerLogin.getContentPane();
		c.setLayout(null);
		f = new Font("Candara", Font.BOLD, 22);

		password = new JLabel("Password   : ");
		password.setBounds(140, 190, 150, 30);
		password.setFont(f);

		userName = new JLabel("User name : ");
		userName.setBounds(140, 150, 150, 30);
		userName.setFont(f);
		userNameField = new JTextField();
		userNameField.setBounds(280, 150, 150, 30);
		userNameField.setFont(f);
		c.add(userName);
		c.add(userNameField);
		c.add(password);

		pf = new JPasswordField();
		pf.setBounds(280, 190, 150, 30);
		pf.setEchoChar('*');// ei function diye icchamoto character set kora jay
		pf.setFont(f);
		c.add(pf);

		// login Button
		loginButton = new JButton("Login");
		loginButton.setBounds(280, 225, 100, 30);
		loginButton.setFont(f);
		c.add(loginButton);
		/// check login and then go to package page
		loginButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent le) {

				if (le.getSource() == loginButton) {
					String userName = userNameField.getText();
					String password = pf.getText();
					LoginOwner obj = new LoginOwner(userName, password, "o");
					boolean loginStatus = obj.idCheckOwner();

					if (loginStatus == false) {
						pf.setText("");
						userNameField.setText("");
						JOptionPane.showMessageDialog(null, "Enter correct password", "Incorrect password message",
								JOptionPane.PLAIN_MESSAGE);

					} // if login failed

					else {

						Owner object = new Owner();
						object.ownerComponents();
						ownerLogin.dispose();

					} // if login successfull

					
				} // if hit login
			}

		}); // approved
	}// initComponents

}
