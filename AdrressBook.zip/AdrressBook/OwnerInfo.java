package TouristManagementSystem;

abstract  class OwnerInfo {
	abstract int packageCount(Owner r1);
}
