package AddressBook;

import javax.swing.JFrame;
import java.awt.Color;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class FrontPage extends JFrame {
	Container c;
	JButton oButton, tButton, ofButton;
	JTextArea ta;
	JTextField field2, field1;
	Font f, buttonFont;
	Cursor cursor;
	ImageIcon img1, img2;
	JScrollPane scroll;
	JRadioButton male, female;
	ButtonGroup grp;
	JLabel label, owner, tourist, official;
	JComboBox cb;
	

	FrontPage() {
		initComponents();
	}

	public static void main(String[] args) {
		FrontPage frame = new FrontPage();

		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(100, 10, 700, 600); // (x,upor,dan)
		frame.setTitle("AddressBook System(FrontPage.java)");

	}
	

	public void initComponents() {
		c = this.getContentPane();
		c.setLayout(null);
		// c.setBackground(Color.ORANGE);
		this.setBounds(100, 100, 500, 500);
		f = new Font("Candara", Font.BOLD, 30);
		buttonFont = new Font("Candara", Font.BOLD, 13);
		// button
		oButton = new JButton("Submit");
		ofButton = new JButton("Submit");
		tButton = new JButton("Submit");
		tButton.setBounds(400, 257, 100, 25);
		tButton.setFont(buttonFont);
		ofButton.setBounds(400, 285, 100, 25);
		ofButton.setFont(buttonFont);
		oButton.setBounds(400, 285, 100, 25);
		oButton.setFont(buttonFont);
		c.add(tButton);
		c.add(oButton);
		//c.add(ofButton);
		// label
		label = new JLabel("Select what type of user are you?");
		label.setBounds(190, 200, 500, 30);
		label.setFont(f);
		tourist = new JLabel("1: Tourist");
		tourist.setBounds(250, 250, 500, 30);
		tourist.setFont(f);
		owner = new JLabel("2: Owner");
		owner.setBounds(250, 280, 500, 30);
		owner.setFont(f);
		c.add(owner);
		//c.add(official);
		c.add(tourist);
		c.add(label);
		
		//actionListener with buttons
		Handler handler = new Handler();
        tButton.addActionListener(handler);
        oButton.addActionListener(handler);
	}
	
	class Handler implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent submitEvent) {
			if(submitEvent.getSource()==tButton) {
				 TouristIdentity tIdentity = new TouristIdentity();
				 tIdentity.setVisible(true);
				 dispose();
			}
			
			else if(submitEvent.getSource()==oButton) {
				 LoginOwner oIdentity = new LoginOwner("1","1","1");
				 oIdentity.ownerLoginComponents();
				 dispose();
			}
			
			
		}//method
		
	}//handler class

}
