package TouristManagementSystem;

import java.awt.Container;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Owner extends OwnerInfo implements Methods {

	private Scanner x,x1;
	static Container c;
	static JButton select;
	static JTextArea ta;
	static JTextField userNameField, field1;
	static Font f1, f2, f3;

	static Cursor cursor;
	ImageIcon img1, img2;
	JScrollPane scroll;
	JRadioButton male, female;
	ButtonGroup grp;
	static JLabel label11, label22, label23, label24, label25, label26,taxLabel,label30,label100,label101;
	static JComboBox cb;
	static JPasswordField pf;

	public static void main(String[] args) {

	}

	public void openFile() {

		try {
			x = new Scanner(
					new File("C:\\All codes\\Java\\eclipse\\OOPdesignCourse\\src\\TouristManagementSystem\\owner.txt"));
		} catch (Exception e) {
			System.out.println("could not open file\n");
		}
	}

	public String readFile() {
		String a = "";
		while (x.hasNext()) {
			a = x.next();
			return a;
		}
		return a;
	}// method

	public void closeFile() {

		x.close();

	}// method

	public void ownerComponents() {
		// JFrame ownerClass = new JFrame(); //ei line pore lagbe
		
		JFrame ow = new JFrame();
		ow.setVisible(true);
		ow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		ow.setBounds(100, 10, 700, 600); // (x,upor,dan)
		ow.setTitle("Owner page");
		
		
		JLabel[] labelList = new JLabel[10];
		JButton[] buttonList = new JButton[10];

		c = ow.getContentPane();
		c.setLayout(null);
		f1 = new Font("Candara", Font.BOLD, 22);
		label11 = new JLabel("Welcome Owner");
		label11.setBounds(100, 20, 500, 30);
		c.add(label11);
		label11.setFont(f1);
		label22 = new JLabel("Total users  is ");
		label22.setBounds(100, 60, 500, 30);
		c.add(label22);
		label22.setFont(f1);
		String taka = ""; // file theke ante hobe
		//file theke data read kora
	    Owner owObject = new Owner();
	    owObject.openFile();
	    taka = owObject.readFile();
	    //file theke data read kora shesh
		double takaInt =0;
		if(taka.equals("")) { 
			takaInt = 0;
			taka = "0";
		}
		else takaInt = Double.valueOf(taka);
		
		int n = packageCount(owObject);
		
		
		
		
		takaInt = profitCalculation(takaInt);
		label23 = new JLabel(taka);
		label23.setBounds(380, 60, 200, 30);
		c.add(label22);
		label23.setFont(f1);
		c.add(label23);
		label24 = new JLabel("Total profit (30% of sellings) before paying tax is ");
		label24.setBounds(100, 100, 500, 30);
		label24.setFont(f1);
		c.add(label24);

		String profitString = String.valueOf(takaInt);
		label25 = new JLabel(profitString);
		label25.setBounds(560, 100, 500, 30);
		label25.setFont(f1);
		c.add(label25);
		
		//tax calculation
		taxLabel = new JLabel("Total profit (30% of sellings) after paying tax is ");
		taxLabel.setBounds(100, 140, 500, 30);
		String taxProfit = String.valueOf(profitCalculation(takaInt,"t"));
		label30 = new JLabel(taxProfit);
		label30.setBounds(540, 140, 500, 30);
		taxLabel.setFont(f1);
		label30.setFont(f1);
		c.add(label30);
		c.add(taxLabel);

		label26 = new JLabel("Your company's packages are listed below");
		label26.setBounds(100, 180, 500, 30);
		label26.setFont(f1);
		c.add(label26);

		// adding packages on console
		Package p1 = new Package(2);

		int left1 = 100, up1 = 220, width1 = 600, height1 = 30;
		int left2 = 480, up2 = 220, width2 = 130, height2 = 30;
		for (int i = 0; i <p1.packageList.size(); i++) {

			String serial = Integer.toString(i + 1);
			serial = serial + ". ";
			String packName = serial + p1.packageList.get(i);
			String cost = Double.toString(p1.costList.get(i));
			cost = "  " + cost + " BDT";
			packName += cost;
			labelList[i] = new JLabel(packName);
			labelList[i].setBounds(left1, up1, width1, height1);
			buttonList[i] = new JButton("delete?");
			buttonList[i].setBounds(left2, up2, width2, height2);
			labelList[i].setFont(f1);
			buttonList[i].setFont(f1);
			//c.add(buttonList[i]);button enable kor jabe
			c.add(labelList[i]);
			up1 = up1 + height1 + 10;
			up2 = up2 + height2 + 10;
		} // package adding on console

		
		up1 +=10;
		
		label100 = new JLabel("Total package selling is : ");
		label100.setBounds(left1, up1, width1,height1);
		label100.setFont(f1);
		c.add(label100);
		
		String cc = Integer.toString(n);
		 label101 = new JLabel(cc);
		label101.setBounds(left2-140, up1, width2,height2);
		label101.setFont(f1);
		c.add(label101);
		
	}// func
	
	public void openFileReadMode() {

		try {
			x1 = new Scanner(new File("C:\\All codes\\Java\\eclipse\\OOPdesignCourse\\src\\TouristManagementSystem\\packageCount.txt"));
		} catch (Exception e) {
			System.out.println("could not open file\n");
		}
	}
	
	public String readFileReadMode() {
	      String a="";
			while (x1.hasNext()) {
				 a = x1.next();
				return a;
			}
			return a;
		}// method
	public void closeFileReadMode() {

		x1.close();
		
	}// method

	@Override
	int packageCount(Owner r1) {
		r1.openFileReadMode();
    	String c = r1.readFileReadMode();
    	int number = Integer.parseInt(c);
    	r1.closeFileReadMode();
    	
    	return number;
	}
	
	
	@Override
	public double profitCalculation(double sellAmount) {
		// TODO Auto-generated method stub
		return (sellAmount * 30) / 100;
	}
    
	public double profitCalculation(double profit,String tax) {
		return profit-((profit*10)/100);
	}
	@Override
	public void addPackage(String pack) {
		// TODO Auto-generated method stub

	}

	
	

}
