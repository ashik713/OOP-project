package TouristManagementSystem;

public interface Methods {
     public double profitCalculation(double sellAmount);
     public void addPackage(String pack);
}
